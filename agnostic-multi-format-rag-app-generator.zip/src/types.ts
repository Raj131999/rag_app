/**
 * Shared Type Definitions for multi-format RAG & Dynamic Applet Generator
 */

// Format types representing successfully accepted sources
export type RAGSourceType = 
  | 'text'
  | 'curl'
  | 'url'
  | 'pdf'
  | 'docx'
  | 'sql'
  | 'image'
  | 'video';

export interface RAGChunk {
  id: string;
  sourceId: string;
  sourceName: string;
  sourceType: RAGSourceType;
  text: string;
  title: string;
  summary: string;
  tags: string[];
  vector?: number[]; // Local embedding coordinates
}

export interface UrlCrawlJob {
  totalUrls: number;
  processedUrls: number;
  successfulUrls: number;
  failedUrls: number;
  processedPercent: number;
  successPercent: number;
  details: { url: string; status: 'pending' | 'success' | 'failed'; error?: string }[];
}

export interface RAGSource {
  id: string;
  name: string;
  type: RAGSourceType;
  createdAt: string;
  status: 'processing' | 'ready' | 'error';
  errorMessage?: string;
  textPreview: string;
  byteSize: number;
  crawlJob?: UrlCrawlJob;
  videoCrawlJob?: UrlCrawlJob;
}

// Full vector store database representation
export interface RAGDatabase {
  sources: RAGSource[];
  chunks: RAGChunk[];
}

// ----------------------------------------------------
// DYNAMICALLY GENERATED COMPONENT / APPLET SPECIFICATION
// ----------------------------------------------------

export interface DynamicAppStat {
  label: string;
  value: string | number;
  subtext?: string;
  trend?: 'up' | 'down' | 'neutral';
}

export interface DynamicAppFilter {
  key: string;
  label: string;
  type: 'select' | 'search';
  options?: string[];
}

export interface DynamicAppChart {
  id: string;
  title: string;
  type: 'bar' | 'line' | 'area' | 'pie';
  xAxisKey: string;
  dataKeys: string[]; // Metrics to draw
  data: Record<string, any>[]; // Chart points
}

export interface DynamicAppTableColumn {
  key: string;
  label: string;
}

export interface DynamicAppTable {
  title: string;
  columns: DynamicAppTableColumn[];
  rows: Record<string, any>[];
  searchPlaceholder?: string;
}

export interface DynamicAppAIAssistant {
  welcomeMessage: string;
  promptPlaceholder: string;
  suggestedQueries: string[];
}

export interface DynamicAppletConfig {
  appId: string;
  title: string;
  description: string;
  theme: 'blue' | 'emerald' | 'amber' | 'rose' | 'indigo' | 'violet' | 'cyan';
  layout: 'dashboard' | 'analytics' | 'explorer' | 'split';
  stats: DynamicAppStat[];
  filters: DynamicAppFilter[];
  charts: DynamicAppChart[];
  table?: DynamicAppTable;
  aiAssistant: DynamicAppAIAssistant;
  contextSources: string[]; // List of source names used for rendering
}

export interface RAGQueryResult {
  answer: string;
  retrievedChunks: {
    title: string;
    sourceName: string;
    sourceType: RAGSourceType;
    text: string;
    score: number;
  }[];
}
