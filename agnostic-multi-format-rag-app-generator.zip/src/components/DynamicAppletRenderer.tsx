import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Search, 
  Send, 
  RotateCcw, 
  Cpu, 
  Table, 
  Layers, 
  History, 
  Compass, 
  Sparkles,
  Loader2,
  FileSpreadsheet,
  BarChart4
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend 
} from 'recharts';
import ReactMarkdown from 'react-markdown';
import { DynamicAppletConfig } from '../types';

interface DynamicAppletRendererProps {
  config: DynamicAppletConfig;
}

export default function DynamicAppletRenderer({ config }: DynamicAppletRendererProps) {
  // Theme styling map
  const themeColors = useMemo(() => {
    switch (config.theme) {
      case 'blue': return {
        primary: 'bg-blue-600 hover:bg-blue-500',
        text: 'text-blue-400',
        border: 'border-blue-500/20',
        bg: 'bg-blue-500/5',
        focus: 'focus:border-blue-500',
        badge: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
        chart: '#3b82f6'
      };
      case 'emerald': return {
        primary: 'bg-emerald-600 hover:bg-emerald-500',
        text: 'text-emerald-400',
        border: 'border-emerald-500/20',
        bg: 'bg-emerald-500/5',
        focus: 'focus:border-emerald-500',
        badge: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
        chart: '#10b981'
      };
      case 'amber': return {
        primary: 'bg-amber-600 hover:bg-amber-500',
        text: 'text-amber-400',
        border: 'border-amber-500/20',
        bg: 'bg-amber-500/5',
        focus: 'focus:border-amber-500',
        badge: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
        chart: '#f59e0b'
      };
      case 'rose': return {
        primary: 'bg-rose-600 hover:bg-rose-500',
        text: 'text-rose-400',
        border: 'border-rose-500/20',
        bg: 'bg-rose-500/5',
        focus: 'focus:border-rose-500',
        badge: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
        chart: '#f43f5e'
      };
      case 'violet': return {
        primary: 'bg-violet-600 hover:bg-violet-500',
        text: 'text-violet-400',
        border: 'border-violet-500/20',
        bg: 'bg-violet-500/5',
        focus: 'focus:border-violet-500',
        badge: 'bg-violet-500/10 text-violet-400 border-violet-500/20',
        chart: '#8b5cf6'
      };
      case 'cyan': return {
        primary: 'bg-cyan-600 hover:bg-cyan-500',
        text: 'text-cyan-400',
        border: 'border-cyan-500/20',
        bg: 'bg-cyan-500/5',
        focus: 'focus:border-cyan-500',
        badge: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
        chart: '#06b6d4'
      };
      default: return {
        primary: 'bg-indigo-600 hover:bg-indigo-500',
        text: 'text-indigo-400',
        border: 'border-indigo-500/20',
        bg: 'bg-indigo-500/5',
        focus: 'focus:border-indigo-500',
        badge: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
        chart: '#6366f1'
      };
    }
  }, [config.theme]);

  // Table filtering and search states
  const [tableSearchText, setTableSearchText] = useState('');
  const [selectFilters, setSelectFilters] = useState<Record<string, string>>({});
  const [sortConfig, setSortConfig] = useState<{ column: string; direction: 'asc' | 'desc' } | null>(null);

  // App Q&A Chat states
  const [chatInput, setChatInput] = useState('');
  const [chatResponse, setChatResponse] = useState<string | null>(null);
  const [isChatting, setIsChatting] = useState(false);

  // Filters mapping
  const activeFilters = config.filters || [];

  // Table calculation & filtering computed logic
  const originalRows = config.table?.rows || [];
  const processedRows = useMemo(() => {
    let filtered = [...originalRows];

    // Apply global text searching
    if (tableSearchText && config.table?.columns) {
      const criteria = tableSearchText.toLowerCase();
      filtered = filtered.filter(row => {
        return Object.values(row).some(val => 
          String(val).toLowerCase().includes(criteria)
        );
      });
    }

    // Apply structured filters
    Object.keys(selectFilters).forEach(key => {
      const selectedVal = selectFilters[key];
      if (selectedVal && selectedVal !== 'All') {
        filtered = filtered.filter(row => 
          String(row[key]) === selectedVal
        );
      }
    });

    // Apply Sorting
    if (sortConfig) {
      filtered.sort((a, b) => {
        const valA = a[sortConfig.column];
        const valB = b[sortConfig.column];
        if (valA === undefined || valB === undefined) return 0;
        
        const isNum = typeof valA === 'number' && typeof valB === 'number';
        if (isNum) {
          return sortConfig.direction === 'asc' ? (valA as number) - (valB as number) : (valB as number) - (valA as number);
        } else {
          const sA = String(valA).toLowerCase();
          const sB = String(valB).toLowerCase();
          return sortConfig.direction === 'asc' 
            ? sA.localeCompare(sB) 
            : sB.localeCompare(sA);
        }
      });
    }

    return filtered;
  }, [originalRows, tableSearchText, selectFilters, sortConfig, config.table?.columns]);

  // Action Q&A trigger
  const handleAppAssistantQuery = async (queryText: string) => {
    if (!queryText || isChatting) return;
    setIsChatting(true);
    setChatResponse(null);

    try {
      const res = await fetch('/api/rag/app-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: queryText,
          appId: config.appId,
          contextSources: config.contextSources
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Server error');
      setChatResponse(data.answer);
    } catch (err: any) {
      setChatResponse(`✖ App Assistant Error: ${err.message || 'Call failed'}`);
    } finally {
      setIsChatting(false);
    }
  };

  const handleStatTrend = (trend?: 'up' | 'down' | 'neutral') => {
    if (trend === 'up') return <TrendingUp className="w-4 h-4 text-emerald-400 shrink-0" />;
    if (trend === 'down') return <TrendingDown className="w-4 h-4 text-rose-400 shrink-0" />;
    return <Compass className="w-4 h-4 text-slate-500 shrink-0" />;
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 font-sans p-6 overflow-y-auto">
      
      {/* Header card banner */}
      <div className={`p-6 rounded-2xl border ${themeColors.border} ${themeColors.bg} relative overflow-hidden backdrop-blur-md`}>
        <div className="flex flex-wrap items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2">
              <span className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded-full border ${themeColors.badge} font-bold`}>
                DYNAMIC COMPONENT INSTANCE: {config.appId}
              </span>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full border border-slate-800 bg-slate-900 text-slate-400 font-bold">
                LAYOUT: {config.layout.toUpperCase()}
              </span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white mt-2 font-sans">{config.title}</h1>
            <p className="text-sm text-slate-400 mt-1 max-w-3xl leading-relaxed">{config.description}</p>
          </div>

          <div className="flex flex-wrap gap-2 text-xs text-slate-500 font-mono self-end">
            <span className="text-slate-600 font-bold">DATA GATHERED FROM:</span>
            {config.contextSources?.map((sourceName, idx) => (
              <span key={idx} className="bg-slate-900 border border-slate-800 px-2 py-1 rounded text-slate-300">
                {sourceName}
              </span>
            ))}
          </div>
        </div>

        {/* Ambient background accent bubble */}
        <div className={`absolute top-0 right-0 w-64 h-64 rounded-full blur-[120px] opacity-10 pointer-events-none ${config.theme === 'rose' ? 'bg-rose-500' : config.theme === 'emerald' ? 'bg-emerald-500' : 'bg-indigo-500'}`} />
      </div>

      {/* KPI Stats widgets grids */}
      {config.stats && config.stats.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          {config.stats.map((stat, idx) => (
            <div key={idx} className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4.5 backdrop-blur-sm shadow-lg flex flex-col justify-between">
              <div>
                <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold font-mono">{stat.label}</span>
                <span className="text-2xl font-extrabold text-white mt-1.5 block tracking-tight font-mono">{stat.value}</span>
              </div>
              {stat.subtext && (
                <div className="flex items-center gap-1.5 mt-3.5 pt-2 border-t border-slate-800/60">
                  {handleStatTrend(stat.trend)}
                  <span className="text-xs text-slate-400 truncate leading-none">{stat.subtext}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Interactive Global filter workspace */}
      {(activeFilters.length > 0 || config.table) && (
        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-4 mt-6 flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-1.5 text-xs text-indigo-400 font-semibold uppercase tracking-wider font-mono mr-2">
            <Layers className="w-4 h-4" />
            <span>Interactive Controls</span>
          </div>

          {/* Table global search field */}
          {config.table && (
            <div className="relative min-w-[200px] flex-1 md:flex-initial">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-3" />
              <input
                type="text"
                placeholder={config.table.searchPlaceholder || "Filter database rows..."}
                value={tableSearchText}
                onChange={(e) => setTableSearchText(e.target.value)}
                className={`w-full text-xs pl-8.5 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-100 placeholder:text-slate-600 focus:outline-none ${themeColors.focus}`}
              />
            </div>
          )}

          {/* Custom Select Filter Lists */}
          {activeFilters.map((filter) => (
            <div key={filter.key} className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-medium">{filter.label}:</span>
              <select
                value={selectFilters[filter.key] || 'All'}
                onChange={(e) => setSelectFilters(prev => ({ ...prev, [filter.key]: e.target.value }))}
                className="text-xs bg-slate-950 text-slate-200 border border-slate-800 rounded-lg px-2.5 py-1.5 focus:outline-none"
              >
                <option value="All">All Categories</option>
                {filter.options?.map((opt, oIdx) => (
                  <option key={oIdx} value={opt}>{opt}</option>
                ))}
              </select>
            </div>
          ))}

          {/* Reset button */}
          {(tableSearchText || Object.keys(selectFilters).length > 0) && (
            <button
              onClick={() => {
                setTableSearchText('');
                setSelectFilters({});
              }}
              className="text-xs flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-800 bg-slate-950 hover:bg-slate-900 cursor-pointer text-slate-300 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset filters
            </button>
          )}
        </div>
      )}

      {/* Main analytical dashboard grids */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-6 min-h-[400px]">
        
        {/* Visualizations (Recharts) Card - occupies left 7 spans or full columns depending on layout */}
        {config.charts && config.charts.length > 0 && (
          <div className={`${config.table ? 'lg:col-span-7' : 'lg:col-span-12'} flex flex-col space-y-6`}>
            {config.charts.map((chart, idx) => (
              <div key={chart.id || idx} className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 shadow-lg backdrop-blur-sm">
                <div className="flex items-center justify-between mb-4 border-b border-slate-800/60 pb-3">
                  <div className="flex items-center gap-2">
                    <BarChart4 className={`w-4 h-4 ${themeColors.text}`} />
                    <h3 className="text-sm font-semibold tracking-wide text-white">{chart.title}</h3>
                  </div>
                  <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded border border-slate-800 text-slate-500 bg-slate-950">
                    Type: {chart.type}
                  </span>
                </div>

                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    {chart.type === 'line' ? (
                      <LineChart data={chart.data} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                        <XAxis dataKey={chart.xAxisKey} stroke="#64748b" fontSize={10} tickLine={false} />
                        <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                        <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }} />
                        <Legend wrapperStyle={{ fontSize: 10 }} />
                        {(chart.dataKeys || []).map((key, kIdx) => (
                          <Line 
                            key={kIdx} 
                            type="monotone" 
                            dataKey={key} 
                            stroke={kIdx === 0 ? themeColors.chart : kIdx === 1 ? '#10b981' : '#f59e0b'} 
                            strokeWidth={2}
                            dot={{ strokeWidth: 1 }}
                          />
                        ))}
                      </LineChart>
                    ) : chart.type === 'area' ? (
                      <AreaChart data={chart.data} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                        <XAxis dataKey={chart.xAxisKey} stroke="#64748b" fontSize={10} tickLine={false} />
                        <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                        <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }} />
                        <Legend wrapperStyle={{ fontSize: 10 }} />
                        {(chart.dataKeys || []).map((key, kIdx) => (
                          <Area 
                            key={kIdx} 
                            type="monotone" 
                            dataKey={key} 
                            fill={kIdx === 0 ? themeColors.chart : kIdx === 1 ? '#10b981' : '#f59e0b'} 
                            fillOpacity={0.15} 
                            stroke={kIdx === 0 ? themeColors.chart : kIdx === 1 ? '#10b981' : '#f59e0b'} 
                          />
                        ))}
                      </AreaChart>
                    ) : (
                      <BarChart data={chart.data} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                        <XAxis dataKey={chart.xAxisKey} stroke="#64748b" fontSize={10} tickLine={false} />
                        <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                        <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }} />
                        <Legend wrapperStyle={{ fontSize: 10 }} />
                        {(chart.dataKeys || []).map((key, kIdx) => (
                          <Bar 
                            key={kIdx} 
                            dataKey={key} 
                            fill={kIdx === 0 ? themeColors.chart : kIdx === 1 ? '#10b981' : '#f59e0b'} 
                            radius={[4, 4, 0, 0]}
                          />
                        ))}
                      </BarChart>
                    )}
                  </ResponsiveContainer>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Local database spreadsheets view */}
        {config.table && (
          <div className={`${config.charts && config.charts.length > 0 ? 'lg:col-span-5' : 'lg:col-span-12'} bg-slate-900/60 border border-slate-800 rounded-xl p-5 shadow-lg backdrop-blur-sm flex flex-col overflow-hidden`}>
            <div className="flex items-center justify-between border-b border-slate-800/60 pb-3 mb-4 shrink-0">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className={`w-4 h-4 ${themeColors.text}`} />
                <h3 className="text-sm font-semibold text-white">{config.table.title || 'Extracted Collection Database'}</h3>
              </div>
              <span className="text-[10px] font-mono text-slate-500 font-bold uppercase">
                Rows: {processedRows.length} of {originalRows.length}
              </span>
            </div>

            {/* Custom Database Table List */}
            <div className="flex-1 overflow-x-auto overflow-y-auto max-h-[360px] border border-slate-800/80 rounded-lg">
              <table className="w-full text-left border-collapse">
                <thead className="bg-[#090d16] border-b border-slate-800 text-[10px] font-mono text-slate-400 uppercase tracking-wider sticky top-0 z-10">
                  <tr>
                    {(config.table?.columns || []).map((col) => (
                      <th 
                        key={col.key} 
                        onClick={() => {
                          let dir: 'asc' | 'desc' = 'asc';
                          if (sortConfig && sortConfig.column === col.key && sortConfig.direction === 'asc') {
                            dir = 'desc';
                          }
                          setSortConfig({ column: col.key, direction: dir });
                        }}
                        className="py-2.5 px-3 font-semibold cursor-pointer select-none hover:text-white hover:bg-slate-900/40"
                      >
                        <div className="flex items-center gap-1.5">
                          {col.label}
                          {sortConfig?.column === col.key && (
                            <span className="text-[8px] text-indigo-400">{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>
                          )}
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-xs text-slate-300 font-mono">
                  {processedRows.length === 0 ? (
                    <tr>
                      <td colSpan={config.table.columns.length} className="text-center py-12 text-slate-600">
                        No database rows match matching filtering criteria.
                      </td>
                    </tr>
                  ) : (
                    processedRows.map((row, rIdx) => (
                      <tr key={rIdx} className="hover:bg-slate-950/40 transition-colors">
                        {(config.table?.columns || []).map((col) => (
                          <td key={col.key} className="py-2.5 px-3 max-w-[200px] truncate leading-normal" title={String(row[col.key])}>
                            {row[col.key] !== null && row[col.key] !== undefined ? String(row[col.key]) : <span className="text-slate-600">-</span>}
                          </td>
                        ))}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* RAG GROUNDED CHAT DIALOG FOR THIS APPLET */}
      {config.aiAssistant && (
        <div className="mt-8 border border-slate-800 bg-slate-900/40 rounded-2xl p-5 shadow-2xl relative">
          <div className="flex items-center gap-2 mb-4">
            <Cpu className={`w-4 h-4 ${themeColors.text} animate-pulse-slow`} />
            <div>
              <h3 className="text-sm font-semibold text-white">Applet Virtual Expert Assistant</h3>
              <p className="text-[10px] text-slate-500 font-mono">CONTEXT CONTAINER CALIBRATION CONFIGURED</p>
            </div>
          </div>

          <div className="text-xs text-slate-300 mb-4 bg-slate-950 border border-slate-850 p-3.5 rounded-xl leading-relaxed">
            {config.aiAssistant?.welcomeMessage}
          </div>

          {/* Quick recommendations queries tag blocks */}
          {config.aiAssistant?.suggestedQueries && config.aiAssistant.suggestedQueries.length > 0 && (
            <div className="mb-4">
              <span className="text-[9px] uppercase font-mono text-slate-500 font-bold block mb-1.5">Suggested Queries:</span>
              <div className="flex flex-wrap gap-2">
                {(config.aiAssistant?.suggestedQueries || []).map((queryText, qIdx) => (
                  <button
                    key={qIdx}
                    onClick={() => {
                      setChatInput(queryText);
                      handleAppAssistantQuery(queryText);
                    }}
                    className={`text-xs text-left px-3 py-1.5 border border-slate-800 hover:border-slate-600 rounded-lg bg-slate-950 hover:bg-slate-900 cursor-pointer text-slate-300 transition-colors flex items-center gap-1.5`}
                  >
                    <Sparkles className="w-3 h-3 text-indigo-400" />
                    {queryText}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Q&A dialog answers stream */}
          {chatResponse && (
            <div className="mb-5 p-4 bg-slate-950 border border-slate-800 rounded-xl max-h-[300px] overflow-y-auto">
              <span className="text-[10px] font-bold text-indigo-400 font-mono block mb-2">ASSISTANT RETRIEVED RESPONSE:</span>
              <div className="text-xs text-slate-300 leading-relaxed prose prose-invert font-sans markdown-body">
                <ReactMarkdown>{chatResponse}</ReactMarkdown>
              </div>
            </div>
          )}

          {/* Form write interface */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleAppAssistantQuery(chatInput);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              required
              placeholder={config.aiAssistant.promptPlaceholder || "Query the application schemas..."}
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              className="flex-1 text-xs bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 focus:outline-none focus:border-indigo-500 placeholder:text-slate-600 text-slate-100"
            />
            <button
              type="submit"
              disabled={isChatting || !chatInput.trim()}
              className={`p-3 rounded-xl flex items-center justify-center cursor-pointer transition-colors ${themeColors.primary} text-white disabled:opacity-40`}
            >
              {isChatting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </button>
          </form>
        </div>
      )}

    </div>
  );
}
