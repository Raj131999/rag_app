import express from 'express';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import { 
  RAGDatabase, 
  RAGSource, 
  RAGChunk, 
  RAGSourceType, 
  DynamicAppletConfig 
} from './src/types.js';

// Load environmental configuration
dotenv.config();

const app = express();
const PORT = 3000;

// Set up server-side Gemini client
const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  console.warn("WARNING: GEMINI_API_KEY environment variable is not set. Please set it in Settings > Secrets.");
}

const ai = new GoogleGenAI({
  apiKey: apiKey || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build'
    }
  }
});

// Configure Multer for processing high-performance uploads (in-memory, up to 50MB)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB limit
});

// File paths for local persistence database
const DB_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'db.json');

// Initialize database storage on startup
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

function loadDatabase(): RAGDatabase {
  if (fs.existsSync(DB_FILE)) {
    try {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(data) as RAGDatabase;
    } catch (err) {
      console.error('Error reading index file. Resetting store.', err);
    }
  }
  return { sources: [], chunks: [] };
}

function saveDatabase(db: RAGDatabase) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to commit database write:', err);
  }
}

// ----------------------------------------------------
// CORE MATHS: VECTOR SIMILARITY IN NODE
// ----------------------------------------------------
function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (!vecA || !vecB || vecA.length !== vecB.length) return 0;
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }
  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

// Basic HTML text parsing / clean extraction helper
function cleanHtml(rawHtml: string): string {
  let cleaned = rawHtml.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '');
  cleaned = cleaned.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');
  cleaned = cleaned.replace(/<\/?[^>]+(x|$)/g, ' ');
  cleaned = cleaned.replace(/\s+/g, ' ').trim();
  return cleaned;
}

// Extract valid HTTP/HTTPS URLs from any text
function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/[a-zA-Z0-9\-\._~:\/\?#\[\]@!\$&'\(\)\*\+,;=%]+/gi;
  const matches = text.match(urlRegex) || [];
  const cleanUrls = matches.map(url => {
    let u = url.trim();
    while (u && ['.', ',', ')', '(', ';', '!', '?', '*', '"', "'"].includes(u[u.length - 1])) {
      u = u.slice(0, -1);
    }
    return u;
  });
  return Array.from(new Set(cleanUrls)).filter(url => {
    try {
      const parsed = new URL(url);
      return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch {
      return false;
    }
  });
}

// Fetch helper with explicit timeout to avoid hanging server actions
async function fetchWithTimeout(url: string, timeoutMs = 12000): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36' },
      signal: controller.signal
    });
    return response;
  } finally {
    clearTimeout(timeoutId);
  }
}

// Asynchronously crawls found URLs in a background queue, updates source crawl job stats,
// and saves computed chunk embeddings back to the local database file.
async function crawlSourceUrlsBackground(sourceId: string, urls: string[]) {
  console.log(`Starting background URL crawler for source: ${sourceId} with ${urls.length} URLs.`);
  
  for (let idx = 0; idx < urls.length; idx++) {
    const targetUrl = urls[idx];
    console.log(`[Crawl Status ${idx + 1}/${urls.length}] Crawling URL: ${targetUrl}`);
    
    // Check if the source or crawlJob has been cleared / deleted by a user reset 
    let db = loadDatabase();
    let source = db.sources.find(s => s.id === sourceId);
    if (!source || !source.crawlJob) {
      console.warn(`Source: ${sourceId} or crawlJob record was removed. Aborting background crawling.`);
      break;
    }

    try {
      // 1. Fetch HTML Page content
      const response = await fetchWithTimeout(targetUrl, 12000);
      if (!response.ok) {
        throw new Error(`HTTP fetch error. Status code: ${response.status}`);
      }
      const rawHtml = await response.text();
      const readableText = cleanHtml(rawHtml);
      
      if (readableText.length < 50) {
        throw new Error("Scraped page has insufficient content density.");
      }

      // 2. Feed text into Gemini 3.5 Flash for expert semantic chunk parsing
      const parsePrompt = `You are an expert web documentation segmenter.
We fetched website information from the URL: "${targetUrl}".
The clean text of this webpage is shown below:

${readableText.substring(0, 10000)}

Please split this content into highly coherent, self-contained semantic knowledge chunks. Remove navigation templates or system footers.
Return your response inside a valid, parseable JSON codeblock matching strictly this schema:
{
  "chunks": [
    {
      "title": "Descriptive header detailing this paragraph's core topic",
      "text": "The full detailed content text extracted",
      "summary": "1-2 sentence quick recap",
      "tags": ["web_resource", "topic_tag"]
    }
  ]
}`;

      const genResponse = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: parsePrompt,
        config: { responseMimeType: 'application/json' }
      });

      const parsedJSON = JSON.parse(genResponse.text || '{}');
      const crawledChunksList = parsedJSON.chunks || [];
      
      if (!Array.isArray(crawledChunksList) || crawledChunksList.length === 0) {
        throw new Error("Gemini returned invalid or empty chunks format.");
      }

      // 3. Compute vector coordinates for each extracted chunk
      const subChunks: RAGChunk[] = [];
      const hostname = new URL(targetUrl).hostname;
      
      for (const raw of crawledChunksList) {
        try {
          const embedRes = await ai.models.embedContent({
            model: "text-embedding-004",
            contents: raw.text || raw.summary || raw.title || ''
          });
          const resAny = embedRes as any;
          const embeddingValues = resAny.embeddings?.[0]?.values || resAny.embeddings?.values || resAny.embedding?.values;
          
          if (embeddingValues) {
            subChunks.push({
              id: `chunk_crawl_${Date.now()}_${Math.floor(Math.random() * 100000)}`,
              sourceId,
              sourceName: `${source.name} [URL: ${hostname}]`,
              sourceType: 'url',
              text: raw.text,
              title: raw.title,
              summary: raw.summary,
              tags: [...(raw.tags || []), 'linked_crawl', 'webpage', `crawled_url:${targetUrl}`],
              vector: embeddingValues
            });
          }
        } catch (embedErr) {
          console.error(`Sub-chunk embedding generation failed for ${targetUrl}:`, embedErr);
        }
      }

      // 4. Update the crawl statistics for successful URL Ingestion
      db = loadDatabase();
      source = db.sources.find(s => s.id === sourceId);
      if (source && source.crawlJob) {
        const itemDetail = source.crawlJob.details.find(d => d.url === targetUrl);
        if (itemDetail) {
          itemDetail.status = 'success';
          itemDetail.error = undefined; // clear any previous error upon success
        }
        source.crawlJob.processedUrls += 1;
        source.crawlJob.successfulUrls += 1;
        source.crawlJob.processedPercent = Math.round((source.crawlJob.processedUrls / source.crawlJob.totalUrls) * 100);
        source.crawlJob.successPercent = source.crawlJob.processedUrls > 0
          ? Math.round((source.crawlJob.successfulUrls / source.crawlJob.processedUrls) * 100)
          : 100;
        
        // Remove pre-existing chunks for this exact URL to guarantee no duplicate embeddings
        db.chunks = db.chunks.filter(c => !c.tags?.includes(`crawled_url:${targetUrl}`));
        db.chunks.push(...subChunks);
        saveDatabase(db);
        console.log(`[Crawl Log] Successfully integrated deep links from: ${targetUrl}`);
      }

    } catch (crawlErr: any) {
      console.error(`Error scraping URL details: ${targetUrl}:`, crawlErr);
      db = loadDatabase();
      source = db.sources.find(s => s.id === sourceId);
      if (source && source.crawlJob) {
        const itemDetail = source.crawlJob.details.find(d => d.url === targetUrl);
        if (itemDetail) {
          itemDetail.status = 'failed';
          itemDetail.error = crawlErr.message || "Request timed out or site blocked crawl request.";
        }
        source.crawlJob.processedUrls += 1;
        source.crawlJob.failedUrls += 1;
        source.crawlJob.processedPercent = Math.round((source.crawlJob.processedUrls / source.crawlJob.totalUrls) * 100);
        source.crawlJob.successPercent = Math.round((source.crawlJob.successfulUrls / source.crawlJob.processedUrls) * 100);
        saveDatabase(db);
      }
    }
    
    // Smooth delay between operations to avoid spam rate limits
    await new Promise(resolve => setTimeout(resolve, 800));
  }
  
  console.log(`Background URL crawler finalized loop execution for source: ${sourceId}.`);
}

// Extract valid video web reference URLs from any text
function extractVideoUrls(text: string): string[] {
  const allUrls = extractUrls(text);
  const videoHostsRegex = /(youtube\.com|youtu\.be|vimeo\.com|dailymotion\.com|twitch\.tv|tiktok\.com|\.(mp4|webm|mov|avi|mkv|flv|3gp|m4v|mp3|wav|ogg|m4a)(\?|$))/i;
  return allUrls.filter(url => videoHostsRegex.test(url));
}

// Asynchronously harvests metadata & chapter guides for dynamic video links in a background queue
async function crawlSourceVideosBackground(sourceId: string, videoUrls: string[]) {
  console.log(`Starting background Video harvester for source: ${sourceId} with ${videoUrls.length} videos.`);
  
  for (let idx = 0; idx < videoUrls.length; idx++) {
    const targetUrl = videoUrls[idx];
    console.log(`[Video Harvest Status ${idx + 1}/${videoUrls.length}] Harvesting Media: ${targetUrl}`);
    
    // Check if the source or videoCrawlJob has been deleted/reset
    let db = loadDatabase();
    let source = db.sources.find(s => s.id === sourceId);
    if (!source || !source.videoCrawlJob) {
      console.warn(`Source: ${sourceId} or videoCrawlJob record was removed. Aborts background video harvester.`);
      break;
    }

    try {
      // 1. Fetch metadata HTML details or headers
      const isDirectVideo = /\.(mp4|webm|mov|avi|mkv|flv|3gp|m4v|mp3|wav|ogg|m4a)(\?|$)/i.test(targetUrl);
      let pageData = "";
      
      if (isDirectVideo) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 6000);
        const headResponse = await fetch(targetUrl, { method: 'HEAD', signal: controller.signal }).catch(() => null);
        clearTimeout(timeoutId);
        
        let contentType = "video/mp4";
        let contentLength = "unknown size";
        if (headResponse) {
          contentType = headResponse.headers.get('content-type') || contentType;
          contentLength = headResponse.headers.get('content-length') || contentLength;
        }
        pageData = `Direct static video file detected.\nURL: ${targetUrl}\nContent-Type: ${contentType}\nContent-Length: ${contentLength} octets.`;
      } else {
        const response = await fetchWithTimeout(targetUrl, 12000);
        if (!response.ok) {
          throw new Error(`HTTP status code error: ${response.status}`);
        }
        const html = await response.text();
        const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
        const title = titleMatch ? titleMatch[1].trim() : '';
        
        const descMatch = html.match(/<meta\s+name=["']description["']\s+content=["']([^"']+)["']/i) || 
                          html.match(/<meta\s+property=["']og:description["']\s+content=["']([^"']+)["']/i);
        const description = descMatch ? descMatch[1].trim() : '';
        
        const pageText = cleanHtml(html).substring(0, 5000);
        pageData = `Video Hosting Webpage crawled details:\nTitle: ${title}\nDescription: ${description}\nHTML Text Snippets:\n${pageText}`;
      }

      // 2. Feed video profile cues into Gemini 3.5 Flash
      const videoServiceLabel = targetUrl.includes('youtube.com') || targetUrl.includes('youtu.be') ? 'YouTube Video Player' : 'Multimedia Video Stream';
      const prompt = `You are a world-class cognitive video narrator, transcript analyst, and segment schema cataloger.
We encountered a video link of type [${videoServiceLabel}] hosted at: "${targetUrl}".

Web scrape, headers, or metadata indicators:
----------------------------------------
${pageData}
----------------------------------------

Please process this video target. Synthesize a sequence of detailed chapter-by-chapter conceptual narration segments.
Explain exactly what information is being shared or shown in each chapter. Give timecodes (e.g. "00:00 - Introduction to the Class", "01:24 - Secondary Phase Setup") and highly thorough, high-fidelity descriptive text blocks. Remove any outer ads or platform filler.

Return your response inside a valid, parseable JSON codeblock matching strictly this schema:
{
  "chunks": [
    {
      "title": "Timecoded chapter header (e.g., 00:00 - Introduction to the Class)",
      "text": "Extremely detailed description or transcription of concepts discussed, instructions, code shown, or topics debated inside this segment",
      "summary": "1-2 sentence recap segment",
      "tags": ["video_lesson", "transcript_section", "media_notes"]
    }
  ]
}`;

      const genResponse = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: { responseMimeType: 'application/json' }
      });

      const parsedJSON = JSON.parse(genResponse.text || '{}');
      const videoChunksList = parsedJSON.chunks || [];
      
      if (!Array.isArray(videoChunksList) || videoChunksList.length === 0) {
        throw new Error("Gemini returned invalid or empty video chunks format.");
      }

      // 3. Compute vector embeddings for our synthesized video segments
      const host = new URL(targetUrl).hostname;
      const subChunks: RAGChunk[] = [];
      
      for (const raw of videoChunksList) {
        try {
          const embedRes = await ai.models.embedContent({
            model: "text-embedding-004",
            contents: raw.text || raw.summary || raw.title || ''
          });
          const resAny = embedRes as any;
          const embeddingValues = resAny.embeddings?.[0]?.values || resAny.embeddings?.values || resAny.embedding?.values;
          if (embeddingValues) {
            subChunks.push({
              id: `chunk_video_${Date.now()}_${Math.floor(Math.random() * 100000)}`,
              sourceId,
              sourceName: `${source.name} [Video: ${host}]`,
              sourceType: 'video',
              text: raw.text,
              title: raw.title,
              summary: raw.summary,
              tags: [...(raw.tags || []), 'video_chapter', 'multimedia', `crawled_url:${targetUrl}`],
              vector: embeddingValues
            });
          }
        } catch (embedErr) {
          console.error(`Sub-chunk embedding generation failed for video ${targetUrl}:`, embedErr);
        }
      }

      // 4. Update the video crawl statistics inside database
      db = loadDatabase();
      source = db.sources.find(s => s.id === sourceId);
      if (source && source.videoCrawlJob) {
        const itemDetail = source.videoCrawlJob.details.find(d => d.url === targetUrl);
        if (itemDetail) {
          itemDetail.status = 'success';
          itemDetail.error = undefined;
        }
        source.videoCrawlJob.processedUrls += 1;
        source.videoCrawlJob.successfulUrls += 1;
        source.videoCrawlJob.processedPercent = Math.round((source.videoCrawlJob.processedUrls / source.videoCrawlJob.totalUrls) * 100);
        source.videoCrawlJob.successPercent = source.videoCrawlJob.processedUrls > 0
          ? Math.round((source.videoCrawlJob.successfulUrls / source.videoCrawlJob.processedUrls) * 100)
          : 100;
        
        // Filter out duplicate video chunks for this exact URL
        db.chunks = db.chunks.filter(c => !c.tags?.includes(`crawled_url:${targetUrl}`));
        db.chunks.push(...subChunks);
        saveDatabase(db);
        console.log(`[Video Crawler] Successfully indexed and computed vectors for: ${targetUrl}`);
      }

    } catch (crawlErr: any) {
      console.error(`Error harvesting Video details: ${targetUrl}:`, crawlErr);
      db = loadDatabase();
      source = db.sources.find(s => s.id === sourceId);
      if (source && source.videoCrawlJob) {
        const itemDetail = source.videoCrawlJob.details.find(d => d.url === targetUrl);
        if (itemDetail) {
          itemDetail.status = 'failed';
          itemDetail.error = crawlErr.message || "Request timed out, failed page resolve, or media block.";
        }
        source.videoCrawlJob.processedUrls += 1;
        source.videoCrawlJob.failedUrls += 1;
        source.videoCrawlJob.processedPercent = Math.round((source.videoCrawlJob.processedUrls / source.videoCrawlJob.totalUrls) * 100);
        source.videoCrawlJob.successPercent = source.videoCrawlJob.processedUrls > 0
          ? Math.round((source.videoCrawlJob.successfulUrls / source.videoCrawlJob.processedUrls) * 100)
          : 100;
        saveDatabase(db);
      }
    }

    // Delay between operations to satisfy rate-limiting rules smoothly
    await new Promise(resolve => setTimeout(resolve, 800));
  }
  
  console.log(`Background Video harvester finalized loop execution for source: ${sourceId}.`);
}

// ----------------------------------------------------
// MIDDLEWARES
// ----------------------------------------------------
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// ----------------------------------------------------
// API ROUTES
// ----------------------------------------------------

// 1. Get List of all Ingested Sources & Metadata
app.get('/api/rag/sources', (req, res) => {
  const db = loadDatabase();
  res.json(db.sources);
});

// 2. Delete an Ingested Source and its Vector chunks
app.delete('/api/rag/sources/:id', (req, res) => {
  const { id } = req.params;
  const db = loadDatabase();
  db.sources = db.sources.filter(s => s.id !== id);
  db.chunks = db.chunks.filter(c => c.sourceId !== id);
  saveDatabase(db);
  res.json({ success: true, message: 'Source deleted successfully' });
});

// 2a. Retry / Rerun specific or all failed crawl URLs
app.post('/api/rag/sources/:sourceId/crawl/retry', async (req, res) => {
  const { sourceId } = req.params;
  const { url } = req.body;

  const db = loadDatabase();
  const source = db.sources.find(s => s.id === sourceId);
  if (!source) {
    return res.status(404).json({ error: 'Source files context not found.' });
  }

  if (!source.crawlJob) {
    return res.status(400).json({ error: 'This resource has no linked URLs to crawl.' });
  }

  // Identify which URLs to rerun
  let urlsToRerun: string[] = [];
  if (url) {
    const detail = source.crawlJob.details.find(d => d.url === url);
    if (!detail) {
      return res.status(404).json({ error: 'Specified URL not found in this source crawl trace.' });
    }
    detail.status = 'pending';
    delete detail.error;
    urlsToRerun = [url];
  } else {
    // Retry all failed or pending url items
    const failedDetails = source.crawlJob.details.filter(d => d.status === 'failed' || d.status === 'pending');
    failedDetails.forEach(d => {
      d.status = 'pending';
      delete d.error;
    });
    urlsToRerun = failedDetails.map(d => d.url);
  }

  if (urlsToRerun.length === 0) {
    return res.json({ success: true, message: 'All URLs are already successfully processed!', crawlJob: source.crawlJob });
  }

  // Recalculate basic counters in crawl statistics
  source.crawlJob.processedUrls = source.crawlJob.details.filter(d => d.status !== 'pending').length;
  source.crawlJob.successfulUrls = source.crawlJob.details.filter(d => d.status === 'success').length;
  source.crawlJob.failedUrls = source.crawlJob.details.filter(d => d.status === 'failed').length;
  source.crawlJob.processedPercent = Math.round((source.crawlJob.processedUrls / source.crawlJob.totalUrls) * 100);
  source.crawlJob.successPercent = source.crawlJob.processedUrls > 0 
    ? Math.round((source.crawlJob.successfulUrls / source.crawlJob.processedUrls) * 100)
    : 100;

  saveDatabase(db);

  // Trigger retry crawling asynchronously
  crawlSourceUrlsBackground(sourceId, urlsToRerun).catch(e => {
    console.error("Retried crawling trigger failed background execution thread:", e);
  });

  res.json({ success: true, message: `Re-queued ${urlsToRerun.length} URLs for crawler background ingestion.`, crawlJob: source.crawlJob });
});

// 2b. Retry / Rerun specific or all failed Video crawl URLs
app.post('/api/rag/sources/:sourceId/video-crawl/retry', async (req, res) => {
  const { sourceId } = req.params;
  const { url } = req.body;

  const db = loadDatabase();
  const source = db.sources.find(s => s.id === sourceId);
  if (!source) {
    return res.status(404).json({ error: 'Source files context not found.' });
  }

  if (!source.videoCrawlJob) {
    return res.status(400).json({ error: 'This resource has no linked Videos to crawl.' });
  }

  // Identify which Video URLs to rerun
  let urlsToRerun: string[] = [];
  if (url) {
    const detail = source.videoCrawlJob.details.find(d => d.url === url);
    if (!detail) {
      return res.status(404).json({ error: 'Specified Video URL not found in this source crawl trace.' });
    }
    detail.status = 'pending';
    delete detail.error;
    urlsToRerun = [url];
  } else {
    // Retry all failed or pending video items
    const failedDetails = source.videoCrawlJob.details.filter(d => d.status === 'failed' || d.status === 'pending');
    failedDetails.forEach(d => {
      d.status = 'pending';
      delete d.error;
    });
    urlsToRerun = failedDetails.map(d => d.url);
  }

  if (urlsToRerun.length === 0) {
    return res.json({ success: true, message: 'All Video URLs are already successfully processed!', videoCrawlJob: source.videoCrawlJob });
  }

  // Recalculate basic counters in crawl statistics
  source.videoCrawlJob.processedUrls = source.videoCrawlJob.details.filter(d => d.status !== 'pending').length;
  source.videoCrawlJob.successfulUrls = source.videoCrawlJob.details.filter(d => d.status === 'success').length;
  source.videoCrawlJob.failedUrls = source.videoCrawlJob.details.filter(d => d.status === 'failed').length;
  source.videoCrawlJob.processedPercent = Math.round((source.videoCrawlJob.processedUrls / source.videoCrawlJob.totalUrls) * 100);
  source.videoCrawlJob.successPercent = source.videoCrawlJob.processedUrls > 0 
    ? Math.round((source.videoCrawlJob.successfulUrls / source.videoCrawlJob.processedUrls) * 100)
    : 100;

  saveDatabase(db);

  // Trigger retry crawling asynchronously
  crawlSourceVideosBackground(sourceId, urlsToRerun).catch(e => {
    console.error("Retried video crawling trigger failed background execution thread:", e);
  });

  res.json({ success: true, message: `Re-queued ${urlsToRerun.length} Videos for background harvesting.`, videoCrawlJob: source.videoCrawlJob });
});

// 3. Reset database completely
app.post('/api/rag/reset', (req, res) => {
  const db: RAGDatabase = { sources: [], chunks: [] };
  saveDatabase(db);
  res.json({ success: true, message: 'Database reset successfully' });
});

// 4. Ingest Text, SQL, or cURL directly from text fields
app.post('/api/rag/ingest-text', async (req, res) => {
  const { name, content, type } = req.body;
  if (!name || !content || !type) {
    return res.status(400).json({ error: 'Name, content, and type selection are required.' });
  }

  const db = loadDatabase();
  const sourceId = `text_${Date.now()}`;
  
  const newSource: RAGSource = {
    id: sourceId,
    name,
    type: type as RAGSourceType,
    createdAt: new Date().toISOString(),
    status: 'processing',
    textPreview: content.substring(0, 200) + (content.length > 200 ? '...' : ''),
    byteSize: Buffer.byteLength(content, 'utf-8')
  };

  db.sources.push(newSource);
  saveDatabase(db);

  try {
    // Phase 1: Ask Gemini to chunk the text intelligently based on format
    const formatLabel = type.toUpperCase();
    const prompt = `You are a world-class documentation parser and semantic schema chunker.
Read and analyze the following extracted content of format: ${formatLabel}. It is named "${name}".

${content}

Process and split this input into a series of highly granular, semantically self-contained knowledge chunks.
- For code snippets (like SQL create table schemas or insert statements), make sure each chunk has complete executable representations or contexts.
- For cURl requests, structure chunks explaining the API endpoints, headers, payloads, query parameters, and a mock expected response.
- Each chunk should provide clear headers and summaries.

Return your response inside a valid, parseable JSON codeblock matching strictly this schema:
{
  "chunks": [
    {
      "title": "A short descriptive title for this specific chunk",
      "text": "The full detailed content text of this chunk including exact parameters, values or instructions",
      "summary": "1-2 sentence quick summary of this information",
      "tags": ["tag1", "tag2"]
    }
  ]
}`;

    const chunkResponse = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const parsedData = JSON.parse(chunkResponse.text || '{}');
    const incomingChunks = parsedData.chunks || [];

    if (!Array.isArray(incomingChunks) || incomingChunks.length === 0) {
      throw new Error("Unable to identify structure in the response generated by Gemini.");
    }

    // Phase 2: Compute Vectors for the gathered sections
    const preparedChunks: RAGChunk[] = [];
    for (const raw of incomingChunks) {
      try {
        const embedRes = await ai.models.embedContent({
          model: "text-embedding-004",
          contents: raw.text || raw.summary || raw.title || ''
        });

        const resAny = embedRes as any;
        const embeddingValues = resAny.embeddings?.[0]?.values || resAny.embeddings?.values || resAny.embedding?.values;
        if (embeddingValues) {
          preparedChunks.push({
            id: `chunk_${Date.now()}_${Math.floor(Math.random() * 10000)}`,
            sourceId,
            sourceName: name,
            sourceType: type as RAGSourceType,
            text: raw.text,
            title: raw.title,
            summary: raw.summary,
            tags: raw.tags || [],
            vector: embeddingValues
          });
        }
      } catch (err) {
        console.error('Failed generating embedding for sub-chunk:', err);
      }
    }

    // Phase 3: Commit and save
    const currentDb = loadDatabase();
    const targetSource = currentDb.sources.find(s => s.id === sourceId);
    if (targetSource) {
      targetSource.status = 'ready';
      targetSource.textPreview = content.substring(0, 300) + (content.length > 300 ? '...' : '');

      // Parse video and standard web URLs for background crawling
      const discoveredVideoUrls = extractVideoUrls(content);
      const discoveredUrls = extractUrls(content).filter(u => !discoveredVideoUrls.includes(u));

      if (discoveredUrls.length > 0) {
        console.log(`Discovered ${discoveredUrls.length} links in scratchpad: ${name}`);
        targetSource.crawlJob = {
          totalUrls: discoveredUrls.length,
          processedUrls: 0,
          successfulUrls: 0,
          failedUrls: 0,
          processedPercent: 0,
          successPercent: 0,
          details: discoveredUrls.map(url => ({ url, status: 'pending' }))
        };

        // Fire asynchronous non-blocking crawl trigger
        crawlSourceUrlsBackground(sourceId, discoveredUrls).catch(e => {
          console.error("Scratchpad background crawling thread triggered an outer error:", e);
        });
      }

      if (discoveredVideoUrls.length > 0) {
        console.log(`Discovered ${discoveredVideoUrls.length} video links in scratchpad: ${name}`);
        targetSource.videoCrawlJob = {
          totalUrls: discoveredVideoUrls.length,
          processedUrls: 0,
          successfulUrls: 0,
          failedUrls: 0,
          processedPercent: 0,
          successPercent: 0,
          details: discoveredVideoUrls.map(url => ({ url, status: 'pending' }))
        };

        // Fire asynchronous non-blocking video harvest trigger
        crawlSourceVideosBackground(sourceId, discoveredVideoUrls).catch(e => {
          console.error("Scratchpad background video crawling thread triggered an outer error:", e);
        });
      }
    }
    currentDb.chunks.push(...preparedChunks);
    saveDatabase(currentDb);

    res.json({ success: true, sourceId, chunksCount: preparedChunks.length });

  } catch (error: any) {
    console.error('Ingestion thread error:', error);
    const errDb = loadDatabase();
    const targetSource = errDb.sources.find(s => s.id === sourceId);
    if (targetSource) {
      targetSource.status = 'error';
      targetSource.errorMessage = error.message || 'Processing and parsing pipeline failed.';
    }
    saveDatabase(errDb);
    res.status(500).json({ error: error.message || 'Failed processing textual source data.' });
  }
});

// 5. Ingest Web URL content
app.post('/api/rag/ingest-url', async (req, res) => {
  const { url, name } = req.body;
  if (!url) {
    return res.status(400).json({ error: 'Valid URL is required.' });
  }

  const label = name || url;
  const db = loadDatabase();
  const sourceId = `url_${Date.now()}`;

  const newSource: RAGSource = {
    id: sourceId,
    name: label,
    type: 'url',
    createdAt: new Date().toISOString(),
    status: 'processing',
    textPreview: `Scraping and analyzing content from URL: ${url}`,
    byteSize: 0
  };

  db.sources.push(newSource);
  saveDatabase(db);

  try {
    // Scraping content from URL
    const fetchResponse = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
    });
    
    if (!fetchResponse.ok) {
      throw new Error(`Failed to download page. Status code received: ${fetchResponse.status}`);
    }

    const htmlContent = await fetchResponse.text();
    const byteSize = Buffer.byteLength(htmlContent, 'utf-8');
    const readableText = cleanHtml(htmlContent);

    // Update size metrics
    const fetchDb = loadDatabase();
    const initialSource = fetchDb.sources.find(s => s.id === sourceId);
    if (initialSource) {
      initialSource.byteSize = byteSize;
    }
    saveDatabase(fetchDb);

    // Call Gemini to structure and chunk the web-scraped contents
    const chunkPrompt = `You are a professional web page content parsing agent.
We scraped HTML text from the URL: "${url}", with document title labeled as "${label}".
The cleaned webpage text is provided below:

${readableText.substring(0, 15000)}

Please review and segment this webpage context into structured, semantic, logical text chunks. Remove any repeating footer navigation, cookies warnings, advertisement widgets, or sidebar indexes.
Focus on maintaining solid, detailed paragraphs regarding key descriptions, statistics, layout instructions, or technical documentations.

Return your response strictly as a parseable JSON block matching this schema:
{
  "chunks": [
    {
      "title": "A short descriptive header of this page section",
      "text": "The full detailed content text extracted for this paragraph",
      "summary": "1-2 sentence quick summary description",
      "tags": ["webpage", "topic", "tag"]
    }
  ]
}`;

    const textGen = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: chunkPrompt,
      config: { responseMimeType: "application/json" }
    });

    const parsedData = JSON.parse(textGen.text || '{}');
    const incomingChunks = parsedData.chunks || [];

    if (!Array.isArray(incomingChunks) || incomingChunks.length === 0) {
      throw new Error("Unable to identify clear structure in the URL response generated by Gemini.");
    }

    // Generate Embeddings
    const preparedChunks: RAGChunk[] = [];
    for (const raw of incomingChunks) {
      try {
        const embedRes = await ai.models.embedContent({
          model: "text-embedding-004",
          contents: raw.text || raw.summary || raw.title || ''
        });

        const resAny = embedRes as any;
        const embeddingValues = resAny.embeddings?.[0]?.values || resAny.embeddings?.values || resAny.embedding?.values;
        if (embeddingValues) {
          preparedChunks.push({
            id: `chunk_${Date.now()}_${Math.floor(Math.random() * 10000)}`,
            sourceId,
            sourceName: label,
            sourceType: 'url',
            text: raw.text,
            title: raw.title,
            summary: raw.summary,
            tags: raw.tags || [],
            vector: embeddingValues
          });
        }
      } catch (err) {
        console.error('Embedding generation failed for url sub-chunk:', err);
      }
    }

    const currentDb = loadDatabase();
    const finalSource = currentDb.sources.find(s => s.id === sourceId);
    if (finalSource) {
      finalSource.status = 'ready';
      finalSource.textPreview = readableText.substring(0, 300) + (readableText.length > 300 ? '...' : '');
    }
    currentDb.chunks.push(...preparedChunks);
    saveDatabase(currentDb);

    res.json({ success: true, sourceId, chunksCount: preparedChunks.length });

  } catch (error: any) {
    console.error('Processing error for ingested URL:', error);
    const errDb = loadDatabase();
    const finalSource = errDb.sources.find(s => s.id === sourceId);
    if (finalSource) {
      finalSource.status = 'error';
      finalSource.errorMessage = error.message || 'Error occurred fetching or parsing the URL content.';
    }
    saveDatabase(errDb);
    res.status(500).json({ error: error.message || 'Scraping and vectorizing url failed.' });
  }
});

// 6. Upload Binary Files (PDFs, DOCX, PNG, MP4, etc.)
app.post('/api/rag/upload', upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file attachment detected in upload.' });
  }

  const { originalname, size, mimetype, buffer } = req.file;
  const extension = path.extname(originalname).toLowerCase();
  
  // Resolve RAGSourceType based on file configurations
  let type: RAGSourceType = 'text';
  if (mimetype.includes('pdf') || extension === '.pdf') {
    type = 'pdf';
  } else if (mimetype.includes('word') || mimetype.includes('officedocument') || extension === '.docx') {
    type = 'docx';
  } else if (mimetype.includes('sql') || extension === '.sql') {
    type = 'sql';
  } else if (mimetype.includes('image') || ['.png', '.jpg', '.jpeg', '.webp', '.gif'].includes(extension)) {
    type = 'image';
  } else if (mimetype.includes('video') || ['.mp4', '.webm', '.mov', '.avi'].includes(extension)) {
    type = 'video';
  } else {
    type = 'text';
  }

  const db = loadDatabase();
  const sourceId = `file_${Date.now()}`;

  const newSource: RAGSource = {
    id: sourceId,
    name: originalname,
    type,
    createdAt: new Date().toISOString(),
    status: 'processing',
    textPreview: `Uploading and performing direct multimodal extraction on file: ${originalname} (${type.toUpperCase()})`,
    byteSize: size
  };

  db.sources.push(newSource);
  saveDatabase(db);

  try {
    // Generate inlineData representation for multimodal inputs
    // For text, sql, docx, we also support general content conversion
    const base64Data = buffer.toString('base64');
    
    // Build context-specific prompt
    const prompt = `You are a world-class multimodal digital RAG parser.
We have received an input file named "${originalname}" of resolved format type: ${type.toUpperCase()}.

Process, extract, and split all contents, texts, definitions, transcription, structural lists, schemas, code, or charts in this document into granular, semantically self-contained sections.
- If it's an image, transcribe all visible words, data grids, tables, and describe visual entities, tags, and design patterns.
- If it's a video, describe the dynamic flow, transcripts (if speech is present), audio cues, key frames, and core content elements.
- If it's a PDF or DOCX, capture all rich text flows, code segments, tables or structures.

Return your response inside a valid, parseable JSON codeblock matching strictly this schema:
{
  "chunks": [
    {
      "title": "A short descriptive header of this document segment",
      "text": "The full detailed content context text extracted (keep tables, logs, curl paths, schemas preserved)",
      "summary": "1-2 sentence description summary",
      "tags": ["document", "context", "relevant-tag"]
    }
  ]
}`;

    const mediaPart = {
      inlineData: {
        mimeType: mimetype || 'application/octet-stream',
        data: base64Data
      }
    };

    const textPart = { text: prompt };

    // Leverage Gemini 3.5 Flash's comprehensive native multimodal understanding
    const genResponse = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: { parts: [mediaPart, textPart] },
      config: { responseMimeType: 'application/json' }
    });

    const parsedData = JSON.parse(genResponse.text || '{}');
    const incomingChunks = parsedData.chunks || [];

    if (!Array.isArray(incomingChunks) || incomingChunks.length === 0) {
      throw new Error(`Multimodal parser created an empty or invalid chunk array.`);
    }

    // Generate Embeddings
    const preparedChunks: RAGChunk[] = [];
    let textPreview = '';

    for (let i = 0; i < incomingChunks.length; i++) {
      const raw = incomingChunks[i];
      if (i === 0) {
        textPreview = raw.text || raw.summary || '';
      }
      try {
        const embedRes = await ai.models.embedContent({
          model: 'text-embedding-004',
          contents: raw.text || raw.summary || raw.title || ''
        });

        const resAny = embedRes as any;
        const embeddingValues = resAny.embeddings?.[0]?.values || resAny.embeddings?.values || resAny.embedding?.values;
        if (embeddingValues) {
          preparedChunks.push({
            id: `chunk_${Date.now()}_${Math.floor(Math.random() * 10000)}`,
            sourceId,
            sourceName: originalname,
            sourceType: type,
            text: raw.text,
            title: raw.title,
            summary: raw.summary,
            tags: raw.tags || [],
            vector: embeddingValues
          });
        }
      } catch (err) {
        console.error('Embedding generation failed for file chunk:', err);
      }
    }

    const currentDb = loadDatabase();
    const finalSource = currentDb.sources.find(s => s.id === sourceId);
    if (finalSource) {
      finalSource.status = 'ready';
      finalSource.textPreview = textPreview.substring(0, 300) + (textPreview.length > 300 ? '...' : '');

      // Parse URLs and Video URLs for background web crawler
      const textBufferContent = (type === 'text' || type === 'sql') ? buffer.toString('utf-8') : '';
      const chunksContentCombined = preparedChunks.map(c => c.text || '').join('\n');
      const aggregatedFileText = `${textBufferContent}\n${chunksContentCombined}`;
      
      const discoveredVideoUrls = extractVideoUrls(aggregatedFileText);
      const discoveredUrls = extractUrls(aggregatedFileText).filter(u => !discoveredVideoUrls.includes(u));

      if (discoveredUrls.length > 0) {
        console.log(`Discovered ${discoveredUrls.length} links inside uploaded file: ${originalname}. Starting background crawler.`);
        finalSource.crawlJob = {
          totalUrls: discoveredUrls.length,
          processedUrls: 0,
          successfulUrls: 0,
          failedUrls: 0,
          processedPercent: 0,
          successPercent: 0,
          details: discoveredUrls.map(url => ({ url, status: 'pending' }))
        };

        // Fire asynchronous non-blocking crawl trigger
        crawlSourceUrlsBackground(sourceId, discoveredUrls).catch(e => {
          console.error("File background URL crawling thread experienced an outer crash:", e);
        });
      }

      if (discoveredVideoUrls.length > 0) {
        console.log(`Discovered ${discoveredVideoUrls.length} video links inside uploaded file: ${originalname}. Starting background video crawler.`);
        finalSource.videoCrawlJob = {
          totalUrls: discoveredVideoUrls.length,
          processedUrls: 0,
          successfulUrls: 0,
          failedUrls: 0,
          processedPercent: 0,
          successPercent: 0,
          details: discoveredVideoUrls.map(url => ({ url, status: 'pending' }))
        };

        // Fire asynchronous non-blocking video harvest trigger
        crawlSourceVideosBackground(sourceId, discoveredVideoUrls).catch(e => {
          console.error("File background video crawler experienced an outer crash:", e);
        });
      }
    }
    currentDb.chunks.push(...preparedChunks);
    saveDatabase(currentDb);

    res.json({ success: true, sourceId, chunksCount: preparedChunks.length });

  } catch (error: any) {
    console.error('File parsing pipeline error:', error);
    const errDb = loadDatabase();
    const finalSource = errDb.sources.find(s => s.id === sourceId);
    if (finalSource) {
      finalSource.status = 'error';
      finalSource.errorMessage = error.message || 'Failed to parse and vectorize the file.';
    }
    saveDatabase(errDb);
    res.status(500).json({ error: error.message || 'Multimodal file analysis failed.' });
  }
});

// 7. General Purpose Vector Search / Match Endpoint
app.post('/api/rag/search', async (req, res) => {
  const { query, sourceIds, limit = 10 } = req.body;
  if (!query) {
    return res.status(400).json({ error: 'Text query string is required.' });
  }

  const db = loadDatabase();
  if (db.chunks.length === 0) {
    return res.json([]);
  }

  try {
    // Phase 1: Embed client's input query
    const embedRes = await ai.models.embedContent({
      model: 'text-embedding-004',
      contents: query
    });

    const resAny = embedRes as any;
    const queryVector = resAny.embeddings?.[0]?.values || resAny.embeddings?.values || resAny.embedding?.values;
    if (!queryVector) {
      throw new Error("Unable to synthesize vector embeddings of input search query.");
    }

    // Filter chunks by selected sources if defined
    let targetChunks = db.chunks;
    if (Array.isArray(sourceIds) && sourceIds.length > 0) {
      targetChunks = db.chunks.filter(c => sourceIds.includes(c.sourceId));
    }

    // Calculate score boundaries
    const list = targetChunks.map(chunk => {
      const score = cosineSimilarity(queryVector, chunk.vector || []);
      return {
        id: chunk.id,
        sourceId: chunk.sourceId,
        sourceName: chunk.sourceName,
        sourceType: chunk.sourceType,
        title: chunk.title,
        text: chunk.text,
        summary: chunk.summary,
        tags: chunk.tags,
        score
      };
    });

    // Sort matching chunks descending by score similarity
    const sorted = list
      .filter(item => item.score > 0.1) // Minimum similarity filter threshold
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);

    res.json(sorted);

  } catch (err: any) {
    console.error('Error in vector query calculation:', err);
    res.status(500).json({ error: err.message || 'Calculation engine failed.' });
  }
});

// 8. RAG Question & Answer assistant (simple query assistant)
app.post('/api/rag/query', async (req, res) => {
  const { question, sourceIds } = req.body;
  if (!question) {
    return res.status(400).json({ error: 'Question string is required.' });
  }

  try {
    const db = loadDatabase();
    // In order to perform RAG, embed user's question first
    let matchingChunks: any[] = [];
    if (db.chunks.length > 0) {
      const embedRes = await ai.models.embedContent({
        model: 'text-embedding-004',
        contents: question
      });
      const resAny = embedRes as any;
      const queryVector = resAny.embeddings?.[0]?.values || resAny.embeddings?.values || resAny.embedding?.values;

      if (queryVector) {
        let targets = db.chunks;
        if (Array.isArray(sourceIds) && sourceIds.length > 0) {
          targets = db.chunks.filter(c => sourceIds.includes(c.sourceId));
        }

        matchingChunks = targets.map(c => {
          const score = cosineSimilarity(queryVector, c.vector || []);
          return { ...c, score };
        })
        .filter(c => c.score > 0.15)
        .sort((a, b) => b.score - a.score)
        .slice(0, 6);
      }
    }

    // Formulate Context for Gemini
    const contextString = matchingChunks.length > 0 
      ? matchingChunks.map((c, i) => `[Source ${i+1}: ${c.sourceName}, Chunk: ${c.title}, Type: ${c.sourceType}]\n${c.text}`).join('\n\n')
      : "No matching context records ingested. Answer drawing strictly from general baseline knowledge.";

    const systemPrompt = `You are a professional knowledge retrieval bot.
Generate a structured, logical, and beautiful response to the user's question.
If useful context is retrieved, ground your responses in that data; explicitly name which files/sources explain the answers.
Always display relevant codes, numbers, parameters, URLs or CURL specs returned in retrieved text inside your answer.

Retrieved Context Chunks:
${contextString}`;

    const chatRes = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: question,
      config: {
        systemInstruction: systemPrompt
      }
    });

    res.json({
      answer: chatRes.text,
      retrievedChunks: matchingChunks.map(c => ({
        title: c.title,
        sourceName: c.sourceName,
        sourceType: c.sourceType,
        text: c.text,
        score: c.score
      }))
    });

  } catch (error: any) {
    console.error('RAG conversation loop issue:', error);
    res.status(500).json({ error: error.message || 'Chat retrieval failed.' });
  }
});

// 9. DYNAMIC APP GENERATOR CANVAS (RAG + APP CREATION PROMPT)
app.post('/api/rag/generate-app', async (req, res) => {
  const { prompt, sourceIds } = req.body;
  if (!prompt) {
    return res.status(400).json({ error: 'Application goal/prompt requirements is required.' });
  }

  try {
    const db = loadDatabase();
    let relevantChunks: any[] = [];

    // Perform vector search with app blueprint prompt to grab contextual assets
    if (db.chunks.length > 0) {
      try {
        const embedRes = await ai.models.embedContent({
          model: 'text-embedding-004',
          contents: prompt
        });
        const resAny = embedRes as any;
        const queryVector = resAny.embeddings?.[0]?.values || resAny.embeddings?.values || resAny.embedding?.values;
        if (queryVector) {
          let targets = db.chunks;
          if (Array.isArray(sourceIds) && sourceIds.length > 0) {
            targets = db.chunks.filter(c => sourceIds.includes(c.sourceId));
          }
          relevantChunks = targets.map(c => ({
            ...c,
            score: cosineSimilarity(queryVector, c.vector || [])
          }))
          .filter(c => c.score > 0.1)
          .sort((a, b) => b.score - a.score)
          .slice(0, 10);
        }
      } catch (err) {
        console.error('RAG vector step missed for App builder payload:', err);
      }
    }

    const contextPayload = relevantChunks.length > 0
      ? relevantChunks.map((c, i) => `[Source ${i+1}: ${c.sourceName}, Chunk: ${c.title}, Type: ${c.sourceType}]\n${c.text}`).join('\n\n')
      : "No custom uploaded context found. Build a creative sample template using mock mock data matching the query specification.";

    const builderSystemInstruction = `You are the master artificial intelligence designer "Anubis Studio".
Your job is to build a complete, highly-polished, fully realizeable configuration JSON matching our "DynamicAppletConfig" TypeScript interface.
This configuration represents a fully functional interactive custom dashboard or diagnostic workspace application designed SPECIFICALLY to serve the user's prompt using the retrieved data files!

The configured output app MUST make complete structural use of the metrics, rows, logs, API details or content described in the user's files.
Do not invent completely unrelated information; calculate or pull numbers, rows, keys, codes, tables, and trends directly from the files!

Available Theme options: "blue" | "emerald" | "amber" | "rose" | "indigo" | "violet" | "cyan". Select a rich theme that fits the vibe.
Available Layout options: "dashboard" (stats & charts), "analytics" (stats & data table details), "explorer" (search tags & records grid), "split" (chats and visualizations).

Each generated app configuration MUST contain:
- Title, descriptive subtext, theme and selected structural layout.
- "stats": Array of 3-4 KPI Stat blocks: { label: string, value: string|number, subtext?: string, trend?: "up" | "down" | "neutral" } representing metrics derived from files (e.g. Total Endpoint Calls, Sum of SQL Transactions, File Records Parse rate, PDF key definitions).
- "filters": Dynamic select box or search boxes to filter tabular elements: { key: string, label: string, type: "select"|"search", options?: string[] }
- "charts": Array of charts that map the data values. Each chart contains a direct array of dataset coordinate objects (e.g., [ { "label": "Revenue", "value": 500 } ] or [ { "timestamp": "12:00", "errors": 3 } ]). Each chart needs dynamic keys for X axis and value bars.
- "table" (optional but highly recommended): A structured database of rows drawn from the files:
  - "columns": matching column keys.
  - "rows": actual parsed records with keys.
- "aiAssistant": Set up custom helper queries related to the app prompt (e.g. "Simulate a cURL payload with user=100", "Show which SQL table has errors").

Do NOT include any external explanation text. Return ONLY the strict DynamicAppletConfig JSON inside a valid json response back. All numbers, dates, rows, lists, metrics, or logs MUST BE EXPLICITLY DRAWN AND DERIVED FROM THE RETRIEVED CONTEXT. If context is empty, construct a pristine prototype interface with high quality template datasets.

---
RETRIEVED CONTEXT FROM INGENTED FILES:
${contextPayload}`;

    const apiCall = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: `Based on the retrieved context, build this customized dashboard/app: ${prompt}`,
      config: {
        systemInstruction: builderSystemInstruction,
        responseMimeType: 'application/json'
      }
    });

    const outputString = apiCall.text || '{}';
    const appletConfig: DynamicAppletConfig = JSON.parse(outputString);

    // Track which raw assets are bound
    appletConfig.contextSources = relevantChunks.length > 0 
      ? Array.from(new Set(relevantChunks.map(c => c.sourceName)))
      : ['Agnostic Baseline Core'];

    // Feed the app source back into the database
    try {
      const liveDb = loadDatabase();
      const appSourceId = `app_${appletConfig.appId || Date.now()}`;
      
      // Make sure we don't duplicate if regenerated
      liveDb.sources = liveDb.sources.filter(s => s.id !== appSourceId);
      liveDb.chunks = liveDb.chunks.filter(c => c.sourceId !== appSourceId);

      // Create a clean textural block describing the app configuration so it can contain complete semantic signals
      const appDescriptionText = `
Applet Configuration Details:
App ID: ${appletConfig.appId}
Title: ${appletConfig.title}
Description: ${appletConfig.description}
Theme: ${appletConfig.theme}
Layout: ${appletConfig.layout}
Context Sources: ${(appletConfig.contextSources || []).join(', ')}

KPI Statistics Configured:
${(appletConfig.stats || []).map(s => `- ${s.label}: ${s.value} (${s.subtext || 'N/A'}, trend: ${s.trend || 'neutral'})`).join('\n')}

Interactive Filters Configured:
${(appletConfig.filters || []).map(f => `- Key: ${f.key}, Label: ${f.label}, Type: ${f.type}, Options: ${(f.options || []).join(', ')}`).join('\n')}

Visualizations/Charts Configured:
${(appletConfig.charts || []).map(c => `- Chart ID: ${c.id}, Title: ${c.title}, Type: ${c.type}, xAxisKey: ${c.xAxisKey}, dataKeys: ${(c.dataKeys || []).join(', ')} (Data points count: ${(c.data || []).length})`).join('\n')}

Data Table Schema Configured:
${appletConfig.table ? `Title: ${appletConfig.table.title || 'N/A'}
Columns: ${(appletConfig.table.columns || []).map(col => `${col.label} (${col.key})`).join(', ')}
Total Rows count: ${(appletConfig.table.rows || []).length}
Featured rows: ${JSON.stringify((appletConfig.table.rows || []).slice(0, 5))}` : 'No table configured.'}

AI Assistant Config:
Welcome Message: ${appletConfig.aiAssistant?.welcomeMessage || 'N/A'}
Suggested Queries: ${(appletConfig.aiAssistant?.suggestedQueries || []).join(', ')}
`;

      const appSource: RAGSource = {
        id: appSourceId,
        name: `Applet Instance: ${appletConfig.title}`,
        type: 'text',
        createdAt: new Date().toISOString(),
        status: 'ready',
        textPreview: appletConfig.description.substring(0, 200),
        byteSize: Buffer.byteLength(appDescriptionText, 'utf-8')
      };

      // Let's generate an embedding for this beautiful applet documentation block!
      const embedRes = await ai.models.embedContent({
        model: "text-embedding-004",
        contents: appDescriptionText
      });
      const resAny = embedRes as any;
      const embeddingValues = resAny.embeddings?.[0]?.values || resAny.embeddings?.values || resAny.embedding?.values;

      if (embeddingValues) {
        const appChunk: RAGChunk = {
          id: `chunk_${appSourceId}_main`,
          sourceId: appSourceId,
          sourceName: appSource.name,
          sourceType: 'text',
          text: appDescriptionText,
          title: `App Schema metadata for ${appletConfig.title}`,
          summary: `Configuration layout, KPI metrics, chart and table definitions for dynamically created applet "${appletConfig.title}".`,
          tags: ['applet_config', appletConfig.theme, appletConfig.layout, 'dynamic_app'],
          vector: embeddingValues
        };

        liveDb.sources.push(appSource);
        liveDb.chunks.push(appChunk);
        saveDatabase(liveDb);
        console.log(`Successfully fed Applet: "${appletConfig.title}" back into RAG knowledge database!`);
      }
    } catch (feedErr) {
      console.error('Failed to automatically feed generated app configuration into RAG database:', feedErr);
    }

    res.json(appletConfig);

  } catch (error: any) {
    console.error('App creator pipeline failed:', error);
    res.status(500).json({ error: error.message || 'App engineering engine failed.' });
  }
});

// 10. SANDBOXED AI ASSISTANT QUERY INSIDE THE GENERATED APP
app.post('/api/rag/app-query', async (req, res) => {
  const { question, appId, contextSources } = req.body;
  if (!question) {
    return res.status(400).json({ error: 'User query is empty.' });
  }

  try {
    const db = loadDatabase();
    // Retrieve source text for matching bound source names
    let extractedContextText = "";
    if (Array.isArray(contextSources) && contextSources.length > 0) {
      const parentSources = db.sources.filter(s => contextSources.includes(s.name));
      if (parentSources.length > 0) {
        const sourceIds = parentSources.map(s => s.id);
        const relatedChunks = db.chunks.filter(c => sourceIds.includes(c.sourceId));
        extractedContextText = relatedChunks.map(c => `[Source Chunk ${c.title}]\n${c.text}`).join('\n\n');
      }
    }

    const systemInstruction = `You are a dedicated local micro-applet Q&A representative inside "${appId}".
Your scope is restricted to the retrieved sources referenced by this applet.
Answer questions accurately, briefly, and cleanly. Use bullet points or code blocks where applicable.

Retrieved Grounding Sources Context:
${extractedContextText || 'Baseline virtual mock environment context.'}`;

    const resAnswer = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: question,
      config: {
        systemInstruction
      }
    });

    res.json({ answer: resAnswer.text });

  } catch (err: any) {
    console.error('Applet assistant error:', err);
    res.status(500).json({ error: err.message || 'App assistant query failed.' });
  }
});


// ----------------------------------------------------
// VITE OR STATIC SERVING MIDDLEWARE & STARTUP
// ----------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Bind to host 0.0.0.0 and hardcoded PORT 3000 as required in instructions
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server launched successfully. Listening at http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
