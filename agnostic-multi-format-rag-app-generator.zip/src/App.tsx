import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Sparkles, 
  MessageSquare, 
  Cpu, 
  Terminal, 
  FolderLock, 
  CornerDownRight, 
  Check, 
  AlertTriangle,
  Flame,
  HelpCircle,
  PlusCircle,
  Play,
  RotateCcw,
  Loader2,
  FileCode2,
  BookOpen,
  PanelLeftClose,
  PanelLeft
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import IngestionPanel from './components/IngestionPanel';
import DynamicAppletRenderer from './components/DynamicAppletRenderer';
import { RAGSource, DynamicAppletConfig, RAGChunk, RAGQueryResult } from './types';

interface ChatHistoryItem {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  sources?: any[];
}

export default function App() {
  const [sources, setSources] = useState<RAGSource[]>([]);
  const [selectedSourceIds, setSelectedSourceIds] = useState<string[]>([]);
  const [isSourcesLoading, setIsSourcesLoading] = useState(true);
  const [dbFileSize, setDbFileSize] = useState<number>(0);

  // App navigation state variables
  const [selectedTab, setSelectedTab] = useState<'rag_chat' | 'app_studio'>('app_studio');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Vector standard chat states
  const [chatHistory, setChatHistory] = useState<ChatHistoryItem[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: "Hello! I am your Multilateral Vector RAG Agent. Load PDF manuals, cURL requests, codebases, SQL, images or videos in the left panel. Ask logical questions or select 'App Studio' to build a specialized interactive analyzer applet!",
      timestamp: new Date().toLocaleTimeString()
    }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isQueryingRAG, setIsQueryingRAG] = useState(false);

  // App Studio States
  const [appPrompt, setAppPrompt] = useState('');
  const [isBuildingApp, setIsBuildingApp] = useState(false);
  const [progressiveStep, setProgressiveStep] = useState(0);
  const [appletHistory, setAppletHistory] = useState<DynamicAppletConfig[]>([]);
  const [activeAppId, setActiveAppId] = useState<string | null>(null);

  // Suggested app ideas list
  const suggestedBps = [
    { label: "Postgres Analytics", prompt: "Create an SQL transaction logs visualizer with performance KPI cards, a scatter/area timeline chart showing query errors over hours, and filter selectors." },
    { label: "cURL API Explorer", prompt: "Create an API response sandbox dashboard pulling endpoints, request metrics (stat cards: Avg latency, success percentage), status tags, and curl detail tables." },
    { label: "Document KPI Reader", prompt: "Summarize key parameters, project milestones, stats, task lists, and build an interactive planning timeline tracker from PDF." },
    { label: "Multimedia Visual Frame Deck", prompt: "Extract transcripts, tags, images or video logs, creating a multimedia audit deck with classification stats and logs table." }
  ];

  // Refresh source roster
  const loadSources = async () => {
    setIsSourcesLoading(true);
    try {
      const [sourcesRes, dbSizeRes] = await Promise.all([
        fetch('/api/rag/sources'),
        fetch('/api/rag/db-size')
      ]);

      if (sourcesRes.ok) {
        const data = await sourcesRes.json();
        setSources(data);
        
        // Auto select newly active ones
        if (selectedSourceIds.length === 0 && data && data.length > 0) {
          setSelectedSourceIds((data || []).map((s: RAGSource) => s.id));
        }
      }

      if (dbSizeRes.ok) {
        const dbSizeData = await dbSizeRes.json();
        setDbFileSize(dbSizeData.size);
      }
    } catch (err) {
      console.error('Error loading server sources list and DB size:', err);
    } finally {
      setIsSourcesLoading(false);
    }
  };

  useEffect(() => {
    loadSources();

    // Setup periodic polling interval to monitor live file chunking or background URL crawl statuses
    const pollInterval = setInterval(async () => {
      try {
        const [sourcesRes, dbSizeRes] = await Promise.all([
          fetch('/api/rag/sources'),
          fetch('/api/rag/db-size')
        ]);

        if (sourcesRes.ok) {
          const data = await sourcesRes.json();
          setSources(data);
        }

        if (dbSizeRes.ok) {
          const dbSizeData = await dbSizeRes.json();
          setDbFileSize(dbSizeData.size);
        }
      } catch (err) {
        console.error('Quietly ignored background poll error:', err);
      }
    }, 3000);

    return () => clearInterval(pollInterval);
  }, []);

  // Database resets
  const handlePurgeDatabase = async () => {
    if (!window.confirm("Danger: This will delete ALL uploaded sources and reset your vector indexes. Proceed?")) return;
    try {
      const res = await fetch('/api/rag/reset', { method: 'POST' });
      if (res.ok) {
        setSources([]);
        setSelectedSourceIds([]);
        setChatHistory([{
          id: 'reset_msg',
          sender: 'assistant',
          text: "All vector storages have been purged. Welcome to a fresh environment!",
          timestamp: new Date().toLocaleTimeString()
        }]);
        setAppletHistory([]);
        setActiveAppId(null);
      }
    } catch (err) {
      console.error('Failed to reset DB:', err);
    }
  };

  // Toggle selection filter row
  const toggleSourceSelection = (id: string) => {
    setSelectedSourceIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => setSelectedSourceIds((sources || []).map(s => s.id));
  const handleClearAll = () => setSelectedSourceIds([]);

  // Submit standard RAG query
  const handleRagQuestionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isQueryingRAG) return;

    const userMessage: ChatHistoryItem = {
      id: `chat_${Date.now()}`,
      sender: 'user',
      text: chatInput,
      timestamp: new Date().toLocaleTimeString()
    };

    setChatHistory(prev => [...prev, userMessage]);
    const originalQuery = chatInput;
    setChatInput('');
    setIsQueryingRAG(true);

    try {
      const res = await fetch('/api/rag/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: originalQuery,
          sourceIds: selectedSourceIds
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Response mapping error');

      setChatHistory(prev => [
        ...prev,
        {
          id: `reply_${Date.now()}`,
          sender: 'assistant',
          text: data.answer,
          timestamp: new Date().toLocaleTimeString(),
          sources: data.retrievedChunks
        }
      ]);
    } catch (err: any) {
      setChatHistory(prev => [
        ...prev,
        {
          id: `reply_err_${Date.now()}`,
          sender: 'assistant',
          text: `✖ Vector pipeline error: ${err.message || 'Call failed.'}`,
          timestamp: new Date().toLocaleTimeString()
        }
      ]);
    } finally {
      setIsQueryingRAG(false);
    }
  };

  // Build Dynamic App let Studio Canvas
  const handleCreateDynamicApp = async (promptOverride?: string) => {
    const targetPrompt = promptOverride || appPrompt;
    if (!targetPrompt.trim() || isBuildingApp) return;

    setIsBuildingApp(true);
    setProgressiveStep(0);
    setAppPrompt('');

    // Progressive step timers for visual feedback
    const interval = setInterval(() => {
      setProgressiveStep(prev => (prev < 4 ? prev + 1 : prev));
    }, 1800);

    try {
      const res = await fetch('/api/rag/generate-app', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: targetPrompt,
          sourceIds: selectedSourceIds
        })
      });

      const data: DynamicAppletConfig = await res.json();
      if (!res.ok) throw new Error(data.appId ? 'RAG error' : 'Server exception');

      // Save into historical list
      setAppletHistory(prev => {
        const filtered = prev.filter(app => app.appId !== data.appId);
        return [data, ...filtered];
      });
      setActiveAppId(data.appId);

    } catch (err: any) {
      window.alert(`App Generation Failure: ${err.message || 'Error parsing schema code blocks.'}`);
    } finally {
      clearInterval(interval);
      setIsBuildingApp(false);
      setProgressiveStep(0);
    }
  };

  // Get active selected app let config
  const activeApplet = appletHistory.find(app => app.appId === activeAppId);

  // Progressive label map
  const progressiveLabels = [
    "Scoping vector similarity graphs...",
    "Retrieving context chunks matching prompt requirements...",
    "Synthesizing high-level data values, KPI stats, & columns...",
    "Drawing responsive analytics charts and tables...",
    "Calibrating active sandboxed agent modules..."
  ];

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 font-sans">
      
      {/* Left Sidebar pane - Ingestion Center */}
      <div className={`h-full shrink-0 border-r border-slate-900 flex flex-col overflow-hidden transition-all duration-300 ${
        isSidebarOpen ? 'w-[380px] md:w-[420px]' : 'w-0 overflow-hidden opacity-0 pointer-events-none'
      }`}>
        <IngestionPanel
          sources={sources}
          isLoading={isSourcesLoading}
          onRefreshSources={loadSources}
          selectedSourceIds={selectedSourceIds}
          onToggleSourceSelection={toggleSourceSelection}
          onSelectAllSources={handleSelectAll}
          onClearAllSourcesSelection={handleClearAll}
          dbFileSize={dbFileSize}
        />
      </div>

      {/* Main Canvas Segment */}
      <div className="flex-1 flex flex-col h-full overflow-hidden bg-slate-950">
        
        {/* Top Application Ribbon */}
        <header className="h-[60px] border-b border-slate-800 flex items-center justify-between px-6 bg-slate-950/80 backdrop-blur-md relative z-10 shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsSidebarOpen(prev => !prev)}
              className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-indigo-400 hover:border-indigo-500/30 transition-all cursor-pointer mr-1 flex items-center justify-center active:scale-95"
              title={isSidebarOpen ? "Collapse Sidebar" : "Expand Sidebar"}
            >
              {isSidebarOpen ? (
                <PanelLeftClose className="w-4 h-4 text-slate-400 hover:text-rose-400" />
              ) : (
                <PanelLeft className="w-4 h-4 text-indigo-400 animate-pulse" />
              )}
            </button>
            <div className="p-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <Cpu className="w-5 h-5 animate-pulse-slow" />
            </div>
            <div>
              <h1 className="text-sm font-semibold tracking-wide text-white flex items-center gap-1.5">
                Dynamic RAG Applet Studio
                <span className="text-[9px] bg-slate-900 border border-slate-800 text-slate-400 py-0.5 px-1.5 rounded font-mono font-bold">V1.5 PREVIEW</span>
              </h1>
              <p className="text-[10px] text-slate-400">RAG Vector Retrieval + Real-Time Micro Applet Generation Block</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Database status counters label */}
            <div className="hidden md:flex items-center gap-3 text-[10px] font-mono text-slate-400 border border-slate-800 bg-slate-950 px-3 py-1.5 rounded-lg">
              <span className="flex items-center gap-1">
                <Database className="w-3.5 h-3.5 text-indigo-400" />
                Sources: <b>{sources.length}</b>
              </span>
              <span className="text-slate-700">|</span>
              <span>
                Simulated-Index: <b className="text-emerald-400">Ready</b>
              </span>
            </div>

            {/* Red clear database button */}
            {sources.length > 0 && (
              <button
                onClick={handlePurgeDatabase}
                className="text-xs flex items-center gap-1 py-1.5 px-3 rounded-lg border border-rose-950 bg-rose-950/20 hover:bg-rose-950/40 cursor-pointer text-rose-400 hover:text-rose-300 transition-all font-medium"
                title="Wipe database schemas"
              >
                <Flame className="w-3.5 h-3.5" />
                Wipe Store
              </button>
            )}
          </div>
        </header>

        {/* Tab switch bar */}
        <div className="flex border-b border-slate-900 bg-[#070a10] px-6 py-2 items-center justify-between shrink-0">
          <div className="flex gap-2">
            <button
              onClick={() => setSelectedTab('app_studio')}
              className={`flex items-center gap-1.5 text-xs font-semibold py-1.5 px-3.5 rounded-lg cursor-pointer transition-all ${
                selectedTab === 'app_studio'
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              Applet Studio Canvas
            </button>
            <button
              onClick={() => setSelectedTab('rag_chat')}
              className={`flex items-center gap-1.5 text-xs font-semibold py-1.5 px-3.5 rounded-lg cursor-pointer transition-all ${
                selectedTab === 'rag_chat'
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              Knowledge Base Q&A Chat
            </button>
          </div>

          {/* Selector list dropdown for generated apps list */}
          {selectedTab === 'app_studio' && appletHistory.length > 0 && (
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500 font-mono">APP SHADED DECKS:</span>
              <select
                value={activeAppId || ''}
                onChange={(e) => setActiveAppId(e.target.value)}
                className="bg-slate-900 border border-slate-800 text-slate-200 rounded-lg py-1 px-2.5 max-w-[200px] truncate"
              >
                {(appletHistory || []).map((app, idx) => (
                  <option key={app.appId || idx} value={app.appId}>{app.title}</option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Tab content screens */}
        <div className="flex-1 overflow-hidden relative">
          
          {/* 1. App Builder Canvas tab panel */}
          {selectedTab === 'app_studio' && (
            <div className="h-full w-full flex flex-col overflow-hidden">
              {isBuildingApp ? (
                /* Dynamic building splash screen */
                <div className="flex-1 flex flex-col items-center justify-center bg-[#090c13] text-center p-6 relative">
                  <div className="p-5 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 relative">
                    <Loader2 className="w-10 h-10 text-indigo-400 animate-spin" />
                    <Sparkles className="w-4 h-4 text-amber-400 absolute top-2 right-2 animate-bounce" />
                  </div>
                  <h3 className="text-lg font-bold text-white mt-5">Creating Custom Application</h3>
                  <p className="text-xs text-slate-500 mt-1 max-w-sm leading-relaxed">
                    Executing complete vector similarity audits on files, summarizing statistical metrics, tables, and formulating graphics...
                  </p>
                  
                  {/* Progressive logs indicator */}
                  <div className="mt-8 bg-slate-950 border border-slate-850 p-3 rounded-lg text-left min-w-[340px] max-w-sm rounded overflow-hidden">
                    <span className="text-[9px] uppercase font-mono text-slate-500 font-bold block mb-1.5">App Creator Stage logs:</span>
                    <div className="space-y-1">
                      {progressiveLabels.map((lbl, idx) => {
                        const isDone = idx < progressiveStep;
                        const isCurrent = idx === progressiveStep;
                        return (
                          <div key={idx} className="flex items-center gap-2 text-xs font-mono">
                            {isDone ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                            ) : isCurrent ? (
                              <Loader2 className="w-3.5 h-3.5 text-indigo-400 animate-spin shrink-0" />
                            ) : (
                              <div className="w-3.5 h-3.5 rounded-full bg-slate-900 border border-slate-800 shrink-0" />
                            )}
                            <span className={isDone ? 'text-slate-400' : isCurrent ? 'text-indigo-300 font-medium' : 'text-slate-700'}>
                              {lbl}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              ) : activeApplet ? (
                /* Interactive custom app running sandbox */
                <div className="flex-1 overflow-hidden h-full">
                  <DynamicAppletRenderer config={activeApplet} />
                </div>
              ) : (
                /* Standard initial welcome and suggest prompt list */
                <div className="flex-1 overflow-y-auto p-8 max-w-3xl mx-auto flex flex-col justify-center h-full">
                  <div>
                    <div className="inline-flex items-center gap-1.5 text-indigo-400 text-xs font-bold uppercase font-mono tracking-wider mb-2">
                      <Sparkles className="w-4 h-4" />
                      <span>Elite Generation Canvas</span>
                    </div>
                    <h2 className="text-2xl font-bold tracking-tight text-white">Create Custom App using RAG Data</h2>
                    <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                      Enter any analytical workflow, dashboard, diagnostic deck, or simulator requirement you want to build. 
                      Our model will execute micro-vector similarity across your ingested files, retrieve relevant rows, schemas, code, or lines, 
                      and design a fully functional running interface complete with KPI numbers, charts, spreadsheets, filters, and local virtual experts.
                    </p>
                  </div>

                  {/* suggest blueprint lists */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-6">
                    {suggestedBps.map((bp, bpIdx) => (
                      <div
                        key={bpIdx}
                        onClick={() => handleCreateDynamicApp(bp.prompt)}
                        className="p-3.5 rounded-xl border border-slate-800 bg-slate-950/40 hover:border-indigo-500/50 hover:bg-indigo-950/10 cursor-pointer text-left transition-all group"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white group-hover:text-indigo-400">{bp.label}</span>
                          <Play className="w-3 h-3 text-slate-500 group-hover:text-indigo-400 transition-colors" />
                        </div>
                        <p className="text-[10px] text-slate-500 mt-1.5 leading-normal">{bp.prompt}</p>
                      </div>
                    ))}
                  </div>

                  {/* Form write block */}
                  <div className="mt-8 border border-slate-800 bg-slate-900/20 rounded-2xl p-5 shadow-2xl">
                    <label className="text-[10px] font-semibold tracking-wider text-slate-400 uppercase font-mono block mb-1.5">Describe your custom application / dashboard requirements:</label>
                    <textarea
                      rows={3}
                      placeholder="e.g., Create a PostgreSQL API transaction analyzer displaying errors timelines, stats, and a custom interactive log table matching our metrics files..."
                      value={appPrompt}
                      onChange={(e) => setAppPrompt(e.target.value)}
                      className="w-full text-xs p-3.5 bg-slate-950 text-slate-200 border border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500 placeholder:text-slate-650"
                    />
                    <button
                      onClick={() => handleCreateDynamicApp()}
                      disabled={isBuildingApp || !appPrompt.trim()}
                      className="w-full text-xs font-semibold py-3 px-4 mt-3 bg-indigo-600 hover:bg-indigo-500 cursor-pointer text-white rounded-xl disabled:opacity-40 transition-colors flex items-center justify-center gap-1.5"
                    >
                      <Sparkles className="w-4 h-4" />
                      Build Custom Interactive App Component
                    </button>
                    {sources.length === 0 && (
                      <div className="mt-2 text-[10px] text-amber-500 font-mono flex items-center justify-center gap-1 font-bold">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        WARNING: No uploaded source files active. It will generate beautiful templates instead.
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 2. RAG conversation chat interface */}
          {selectedTab === 'rag_chat' && (
            <div className="h-full w-full flex flex-col bg-[#06080d]">
              
              {/* Chat Message Lists scroll stream */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {(chatHistory || []).map((msg, idx) => (
                  <div key={msg.id || idx} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] rounded-2xl p-4 border relative ${
                      msg.sender === 'user'
                        ? 'bg-indigo-600/15 border-indigo-500/30 text-slate-100'
                        : 'bg-slate-900/60 border-slate-800/80 text-slate-300'
                    }`}>
                      
                      {/* Name Label and time metadata */}
                      <div className="flex items-center gap-1.5 text-[9px] font-mono text-slate-500 font-bold uppercase mb-1">
                        <span>{msg.sender === 'user' ? 'CLIENT PROMPT' : 'VECTOR AGENT'}</span>
                        <span>•</span>
                        <span>{msg.timestamp}</span>
                      </div>

                      {/* Content block rendered raw markdown */}
                      <div className="text-xs leading-relaxed prose prose-invert font-sans markdown-body">
                        <ReactMarkdown>{msg.text}</ReactMarkdown>
                      </div>

                      {/* Collage source lists retrieved tags on vector searching */}
                      {msg.sources && msg.sources.length > 0 && (
                        <div className="mt-4 pt-3 border-t border-slate-800/60 space-y-1.5 select-none">
                          <span className="text-[9px] uppercase font-mono text-slate-500 font-bold block mb-1">Retrieved Grounding Sources Context:</span>
                          <div className="flex flex-col gap-1.5">
                            {(msg.sources || []).map((source, sIdx) => (
                              <details key={source.id || sIdx} className="group-detail bg-slate-950/80 border border-slate-850 p-2 rounded-lg cursor-pointer">
                                <summary className="text-[10px] text-slate-400 font-medium list-none outline-none flex items-center justify-between">
                                  <div className="flex items-center gap-1.5 truncate">
                                    <BookOpen className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                                    <span className="text-slate-300 font-bold truncate max-w-[200px]">{source.sourceName}</span>
                                    <span className="text-[9px] text-slate-500 font-mono italic">({source.title})</span>
                                  </div>
                                  <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 font-semibold border border-indigo-500/10 shrink-0">
                                    Match: {(source.score * 100).toFixed(0)}%
                                  </span>
                                </summary>
                                <p className="text-[10px] text-slate-500 mt-2.5 bg-slate-900 p-2 rounded border border-slate-850 font-mono whitespace-pre-wrap leading-relaxed max-h-[160px] overflow-y-auto">
                                  {source.text}
                                </p>
                              </details>
                            ))}
                          </div>
                        </div>
                      )}

                    </div>
                  </div>
                ))}

                {isQueryingRAG && (
                  <div className="flex justify-start">
                    <div className="max-w-[80%] rounded-2xl p-4 border bg-slate-900/60 border-slate-800/80">
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-3.5 h-3.5 text-indigo-400 animate-spin" />
                        <span className="text-xs text-slate-500 font-mono leading-none">Interrogating indexes, retrieving chunks...</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Message Input bar */}
              <div className="p-4 border-t border-slate-900 bg-slate-950/60 shrink-0">
                <form onSubmit={handleRagQuestionSubmit} className="flex gap-2 max-w-4xl mx-auto">
                  <input
                    type="text"
                    required
                    placeholder={
                      selectedSourceIds.length > 0 
                        ? `Ask a question across ${selectedSourceIds.length} active vector chunks...` 
                        : "Ask a general question... (Upload files on the left to activate full RAG vector grounding)"
                    }
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    className="flex-1 text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:border-indigo-500 text-slate-100 placeholder:text-slate-600"
                  />
                  <button
                    type="submit"
                    disabled={isQueryingRAG || !chatInput.trim()}
                    className="bg-indigo-600 hover:bg-indigo-500 cursor-pointer text-white px-5 py-3 rounded-xl text-xs font-semibold disabled:opacity-40 transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>Fetch Context</span>
                  </button>
                </form>
              </div>

            </div>
          )}

        </div>

      </div>

    </div>
  );
}
